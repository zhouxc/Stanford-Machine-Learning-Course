function [X,y] = load_data

X = load('data/x.dat');
y = load('data/y.dat');