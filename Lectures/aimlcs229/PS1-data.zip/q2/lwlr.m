function y = lwlr(X_train, y_train, x, tau)

%%% YOUR CODE HERE