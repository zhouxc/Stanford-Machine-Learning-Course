function theta = l1l2(X,y,lambda)

%%% YOUR CODE HERE