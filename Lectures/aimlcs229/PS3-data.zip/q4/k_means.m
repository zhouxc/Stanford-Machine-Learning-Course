function [clusters, centroids] = k_means(X, k)

%%% YOUR CODE HERE