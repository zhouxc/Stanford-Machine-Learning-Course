function W = ica(X)

%%% YOUR CODE HERE

