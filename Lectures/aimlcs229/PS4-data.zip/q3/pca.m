function U = pca(X)

%%% YOUR CODE HERE
