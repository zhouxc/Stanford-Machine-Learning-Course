function [X,y,theta_true] = load_data

X = load('x.dat');
y = load('y.dat');
theta_true = load('theta.dat');